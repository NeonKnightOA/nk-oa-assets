the mm3d opens in Misfit Model 3D, a cross platform 3D modeling tool available from http://www.misfitcode.com/misfitmodel3d/ the current developement snapshot includes native md3 support.
